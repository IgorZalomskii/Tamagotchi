package com.example.interfaceforproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity{



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button Hall = (Button) findViewById(R.id.hall);
        Button Kitchen = (Button) findViewById(R.id.kitchen);
        Button Toilet = (Button) findViewById(R.id.toilet);
        Button Bedroom = (Button) findViewById(R.id.bedroom);

        Hall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.setClass(MainActivity.this, FragmentHall.class);
                startActivity(i);
            }
        });

        Kitchen.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.setClass(MainActivity.this, FragmentKitchen.class);
                startActivity(i);
            }
        });

        Toilet.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.setClass(MainActivity.this, FragmentToilet.class);
                startActivity(i);
            }
        });

        Bedroom.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, FragmentBedroom.class);
                startActivity(i);
            }
        });

    }

}
