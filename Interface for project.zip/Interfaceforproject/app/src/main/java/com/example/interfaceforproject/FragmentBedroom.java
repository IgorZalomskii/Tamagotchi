package com.example.interfaceforproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class FragmentBedroom extends AppCompatActivity {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_bedroom);

        //Основные детали(зал, кухня, туалет, сапльня).
        //Зал
        Button hall = findViewById(R.id.hall);
        hall.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FragmentBedroom.this, FragmentHall.class);
                startActivity(i);
            }
        });

        //Кухня
        Button kitchen = findViewById(R.id.kitchen);
        kitchen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FragmentBedroom.this, FragmentKitchen.class);
                startActivity(i);
            }
        });

        //Туалет
        Button toilet = findViewById(R.id.toilet);
        toilet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FragmentBedroom.this, FragmentToilet.class);
                startActivity(i);
            }
        });

        //Доп. контент комнаты.
        //Игра
        Button game = findViewById(R.id.game);
        game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FragmentBedroom.this, FragmentGame.class);
                startActivity(i);

            }
        });

        //Магазин интерьера
        Button shop = findViewById(R.id.shop);
        shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FragmentBedroom.this, FragmentShop.class);
                startActivity(i);

            }
        });
    }
}
