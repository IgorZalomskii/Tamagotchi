package com.example.interfaceforproject;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class FragmentShop extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_kitchen);
    }
}
